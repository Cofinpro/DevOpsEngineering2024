package com.example.devopsengineering.micrometer;

import io.micrometer.core.instrument.MeterRegistry;
import org.springframework.context.annotation.Bean;

public class TimedAspect {
    @Bean
    public TimedAspect timedAspect(MeterRegistry registry) {
        return new TimedAspect();
    }
}
