package com.example.devopsengineering;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DevOpsEngineeringApplication {

    public static void main(String[] args) {
        SpringApplication.run(DevOpsEngineeringApplication.class, args);
    }

}
