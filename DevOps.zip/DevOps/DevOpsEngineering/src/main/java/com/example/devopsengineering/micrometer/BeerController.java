package com.example.devopsengineering.micrometer;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
public class BeerController{
    private final MeterRegistry meterRegistry;
    private Counter lightOrderCounter;
    private Counter aleOrderCounter;

    private List<Order> orders = new ArrayList<>();

    public BeerController(MeterRegistry meterRegistry) {
        this.meterRegistry = meterRegistry;
        initOrderCounters();
    }

    private void initOrderCounters() {
    }

    @GetMapping("/orderBeer")
    public void orderBeer(String type) {
        if ("ale".equals(type)) {
            Order newOrder = new Order(1, "ale");
            orders.add(newOrder);
        }
        if ("light".equals(type)) {
            Order newOrder = new Order(1, "light");
            orders.add(newOrder);
        }
    }
    
    @Scheduled(fixedRate = 5000)
    public void serveFirstOrder() throws InterruptedException {
        if (!orders.isEmpty()) {
            Order remove = orders.remove(0);
            Thread.sleep(1000L * remove.amount);
        }
    }
}

class Order {
    int amount;
    String type;

    public Order(int amount, String type) {
        this.amount = amount;
        this.type = type;
    }
}
